Javascripting Coding
------------------

<script src="jsfiles/html2canvas.min.js"></script>
    <script src="jsfiles/pdfmake.min.js"></script>
    <script type="text/javascript">
        function Export() {
            alert("hello");
            html2canvas(document.getElementById('admitcard'), {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("AdmitCard.pdf");
                    alert("Admit Card Downloading Started");
                }
            });
        }
    </script>


---------------

<input type="button" id="btnExport" value="Export" onclick="Export()" class="auto-style5" />


---------------



/*$(document).ready(function(){
	
	var specialElementHandlers = {
		"#editor":function(element,renderer){
			return true;
		}
	};
	

$("#dnload").click(function(){
	var doc = new jsPDF();
	doc.fromHTML($("#target").html(),1,1,{
		"width":1000,
		"elementHandlers":specialElementHandlers
	});
	doc.save("sample.file.pdf");
});


});